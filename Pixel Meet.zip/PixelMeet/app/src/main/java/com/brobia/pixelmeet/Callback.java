package com.brobia.pixelmeet;

public interface Callback {
    void onComplete();
}
